# Shaikh Aseel — Portfolio

A dark, animated, single-page developer portfolio. Vanilla HTML/CSS/JS, no build step.

## Structure

```
portfolio/
├── index.html        Page markup and content
├── css/
│   └── style.css      All styling, theming, and animations
├── js/
│   └── script.js       Interactivity (menu, theme, reveal animations, contribution graph, etc.)
├── assets/            Put your banner video / images here
└── README.md
```

## Run it

No build tools needed. Just open `index.html` in a browser, or serve it locally:

```bash
cd portfolio
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## What's included

- **Full-bleed looping banner video** — edge-to-edge, square corners, spans the whole viewport width — with a live digital clock in the top-right corner
- **⌘K Navigation Menu** — a real command palette (click the ⌘K pill or press Cmd/Ctrl+K): search-filterable list of sections and actions, arrow-key navigation, Enter to select, Esc to close, plus global `shift + letter` shortcuts (E/P/B/O/S for sections, C for Copy Link, T/D/Y for Light/Dark/System theme)
- **Live GitHub Activity** — the contribution graph and stats (contributions, public repos, followers) are fetched in real time for `github.com/aseel012` using the GitHub REST API and the jogruber contributions API. If the API is rate-limited or offline, it shows a friendly fallback instead of fake numbers.
- **Loading screen** on first paint
- **Scroll-reveal animations** for each section (fades + slides in via `IntersectionObserver`)
- **Staggered card animations** for the Projects grid
- **Scroll-spy navigation** — the active section gets a leading "—" and bold text
- **Light / Dark / System theme**, saved to `localStorage`
- **Typing effect** in the bio line, cycling through role titles
- **Filterable Open Source list** (All / Merged / Open tabs)
- **Back-to-top button** that appears after scrolling
- No emoji anywhere — experience and tech-stack markers are clean monogram/letter badges instead
- Respects `prefers-reduced-motion`
- Responsive across desktop, tablet, and mobile, with a slide-out mobile nav

## Customize

- **Content**: edit the text directly in `index.html` — experience, projects (8 included), skills, and blog posts are plain markup, no templating.
- **Colors**: all colors are CSS variables at the top of `css/style.css` under `:root` (dark) and `html.light` (light theme).
- **Banner video**: it ships pointing at a free CC0 stock clip so it works immediately. To use your own: drop a video file into `assets/` and change the `<source src="...">` in `.page-banner`.
- **Banner clock**: shows the visitor's local time (`HH:MM:SS`), top-right of the banner, updated client-side in `initBannerClock()` in `js/script.js`.
- **Avatar**: replace the GitHub avatar URL in the `<img>` tag with your own image, or drop a local file into `assets/`.
- **Booking link**: update the `href` on the "Book an intro call" button (currently a placeholder Cal.com link).
- **Resume link**: update the `href` on the "Resume" pill in the socials row.
- **GitHub username**: change `GITHUB_USERNAME` at the top of the "Command Palette" block in `js/script.js` if you ever change handles — it drives both the live activity graph and the GitHub social link.
- **Command palette actions**: add/remove entries in the `CMDK_ACTIONS` array in `js/script.js` — each one is `{ group, label, icon, key, run }`.

## Browser support

Modern evergreen browsers (Chrome, Firefox, Safari, Edge). Uses `IntersectionObserver`, CSS custom properties, and `grid` — no polyfills included.
